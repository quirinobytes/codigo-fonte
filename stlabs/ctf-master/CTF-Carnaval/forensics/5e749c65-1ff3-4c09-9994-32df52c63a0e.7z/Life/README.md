# Title: Give life to the letters

# Description:
    Apply the Conways' game to the text.
    Use the same Rules with an aditional one:
        5. Any dead cell with exactly three live neighbours will come to life with the same value of the highest value of the three neighbours.
	   The newly born cells are selected from the maximum, based on ASCII, from the three neighbors that spawned it. 
            Ex: ['l', 'l', 'o'] the 'o' born.
	    _____    _____ 
	   |     |  |     |
	   |  He |  | lHe |
	   | ll  |  | l   |
	   |  o  |  | oo  |
	    -----    -----

    The flag will be the concatenation of the letters resulted after 785th generations.
	An example of flag generated is in the end of the file text-output.txt attached.

	Sample Files:
	text-input: Text to use to test your algorithm
	text-output: Result after running the algorithm on the text-input

	Submit the flag with the folloing format:
		shellter{string}
	